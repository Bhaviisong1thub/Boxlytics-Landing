import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function ComingSoon() {
  const [darkMode, setDarkMode] = useState(false);
  const [email, setEmail] = useState("");

  useEffect(() => {
    document.body.style.backgroundColor = darkMode ? "#0e0e0e" : "#ffffff";
  }, [darkMode]);

  return (
    <div
      className={`min-h-screen flex flex-col items-center justify-center px-6 py-12 transition-all duration-500 ${
        darkMode ? "bg-black text-white" : "bg-white text-gray-900"
      }`}
    >
      <div className="absolute top-4 right-4">
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="p-2 rounded-full bg-gray-200 dark:bg-gray-700 hover:scale-110 transition-all"
        >
          {darkMode ? "🌞" : "🌙"}
        </button>
      </div>

      <motion.h1
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1 }}
        className="text-4xl sm:text-6xl font-extrabold mb-4 text-center"
      >
        Boxlytics
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 1 }}
        className="text-xl sm:text-2xl mb-8 text-center max-w-2xl"
      >
        We're building the smartest way to optimize subscription box profits.
        Be the first to know when we launch.
      </motion.p>

      <motion.form
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1, duration: 0.8 }}
        className="w-full max-w-md"
        onSubmit={(e) => {
          e.preventDefault();
          alert("We'll notify you soon!"); // Replace with backend logic
        }}
      >
        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all dark:bg-gray-800 dark:text-white"
        />
        <button
          type="submit"
          className="w-full mt-4 p-3 rounded-lg bg-blue-600 text-white font-semibold hover:bg-blue-700 transition-all"
        >
          Notify Me
        </button>
      </motion.form>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.5 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="mt-16 text-sm"
      >
        Launching on <span className="font-semibold">May 17, 2025</span>
      </motion.div>
    </div>
  );
}
